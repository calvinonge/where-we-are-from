// Enhanced word cloud with better layout and PDF generation
class WordCloudGenerator {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.words = [];
    }

    // Generate word cloud with better positioning
    generateCloud(words) {
        this.words = words;
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        if (words.length === 0) {
            this.drawEmptyState();
            return;
        }

        // Prepare word data with sizes and colors
        const wordData = this.prepareWordData(words);
        
        // Position words using spiral placement
        const positionedWords = this.positionWords(wordData);
        
        // Draw the words
        this.drawWords(positionedWords);
    }

    prepareWordData(words) {
        return words.map((word, index) => {
            const frequency = words.filter(w => w === word).length;
            const baseSize = Math.max(16, Math.min(48, 20 + frequency * 8));
            const size = Math.max(baseSize, 32 - (index * 1.5));
            
            return {
                text: word,
                size: size,
                color: this.getWordColor(index),
                width: 0,
                height: 0
            };
        });
    }

    getWordColor(index) {
        const colors = [
            '#4a9b9b', // Teal
            '#d4a574', // Amber  
            '#a64545', // Crimson
            '#6b7280', // Gray
            '#059669', // Emerald
            '#7c3aed', // Violet
            '#dc2626', // Red
            '#ea580c'  // Orange
        ];
        return colors[index % colors.length];
    }

    positionWords(wordData) {
        const positioned = [];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const maxRadius = Math.min(this.canvas.width, this.canvas.height) / 2 - 50;

        wordData.forEach((word, index) => {
            // Measure text dimensions
            this.ctx.font = `${word.size}px Inter`;
            const metrics = this.ctx.measureText(word.text);
            word.width = metrics.width;
            word.height = word.size;

            let x, y;
            let attempts = 0;
            const maxAttempts = 100;

            do {
                if (index === 0) {
                    // Place first word in center
                    x = centerX;
                    y = centerY;
                } else {
                    // Spiral placement for other words
                    const angle = (index * 137.5) * (Math.PI / 180); // Golden angle
                    const radius = Math.min(maxRadius, (index * 15));
                    x = centerX + Math.cos(angle) * radius;
                    y = centerY + Math.sin(angle) * radius;
                    
                    // Add some randomness
                    x += (Math.random() - 0.5) * 40;
                    y += (Math.random() - 0.5) * 40;
                }

                attempts++;
            } while (this.hasCollision(x, y, word, positioned) && attempts < maxAttempts);

            // Ensure word stays within canvas bounds
            x = Math.max(word.width / 2, Math.min(this.canvas.width - word.width / 2, x));
            y = Math.max(word.height / 2, Math.min(this.canvas.height - word.height / 2, y));

            positioned.push({
                ...word,
                x: x,
                y: y
            });
        });

        return positioned;
    }

    hasCollision(x, y, word, positioned) {
        const padding = 10;
        
        return positioned.some(other => {
            const dx = Math.abs(x - other.x);
            const dy = Math.abs(y - other.y);
            const minDistX = (word.width + other.width) / 2 + padding;
            const minDistY = (word.height + other.height) / 2 + padding;
            
            return dx < minDistX && dy < minDistY;
        });
    }

    drawWords(words) {
        words.forEach(word => {
            this.ctx.fillStyle = word.color;
            this.ctx.font = `${word.size}px Inter`;
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            
            // Add subtle shadow
            this.ctx.shadowColor = 'rgba(0, 0, 0, 0.1)';
            this.ctx.shadowBlur = 2;
            this.ctx.shadowOffsetX = 1;
            this.ctx.shadowOffsetY = 1;
            
            this.ctx.fillText(word.text, word.x, word.y);
            
            // Reset shadow
            this.ctx.shadowColor = 'transparent';
            this.ctx.shadowBlur = 0;
            this.ctx.shadowOffsetX = 0;
            this.ctx.shadowOffsetY = 0;
        });
    }

    drawEmptyState() {
        this.ctx.fillStyle = '#999';
        this.ctx.font = '16px Inter';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(
            'Add some words to create your cloud!', 
            this.canvas.width / 2, 
            this.canvas.height / 2
        );
    }
}

// Enhanced PDF generation
class PDFGenerator {
    static async generatePDF(words, prompts) {
        // Create a more comprehensive PDF content
        const content = this.createPDFContent(words, prompts);
        
        // For now, create a rich text file that could be converted to PDF
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `where-we-are-from-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    static createPDFContent(words, prompts) {
        const date = new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        return `
WHERE WE'RE FROM
Group Portrait & Reflection Summary

Generated on: ${date}

═══════════════════════════════════════════════════════════════

COLLECTED WORDS & PHRASES
${words.length > 0 ? words.map(word => `• ${word}`).join('\n') : '• No words collected'}

═══════════════════════════════════════════════════════════════

PROMPTS EXPLORED

Surface Tier (Ice-breakers & Light Reflection):
${prompts.surface ? prompts.surface.slice(0, 5).map(p => `• ${p}`).join('\n') : '• No surface prompts available'}

Story Tier (Shared Memories & Personal Turning Points):
${prompts.story ? prompts.story.slice(0, 5).map(p => `• ${p}`).join('\n') : '• No story prompts available'}

Soul Tier (Values, Fears & Unanswered Questions):
${prompts.soul ? prompts.soul.slice(0, 5).map(p => `• ${p}`).join('\n') : '• No soul prompts available'}

═══════════════════════════════════════════════════════════════

REFLECTION NOTES
(Space for personal notes and insights)

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

═══════════════════════════════════════════════════════════════

"Where We're From" is a vulnerability-prompt game exploring 
identity, memory, and belonging across cities, cultures, and 
generations.

This document serves as a keepsake of your group's shared 
journey through the three tiers of reflection.
        `.trim();
    }
}

// Theme selector functionality
class ThemeManager {
    constructor() {
        this.themes = {
            'identity': 'Identity & Heritage',
            'diaspora': 'Diaspora & Migration',
            'love_boundaries': 'Love & Boundaries',
            'health_body': 'Health & Body'
        };
        this.currentTheme = 'identity';
        this.customPrompts = null;
    }

    async loadCustomPrompts() {
        try {
            const response = await fetch('./decks/custom-themes.json');
            this.customPrompts = await response.json();
        } catch (error) {
            console.error('Error loading custom themes:', error);
            this.customPrompts = {};
        }
    }

    getPromptsForTheme(theme) {
        if (theme === 'identity') {
            return gameState.prompts;
        }
        return this.customPrompts[theme] || gameState.prompts;
    }

    createThemeSelector() {
        const selector = document.createElement('div');
        selector.className = 'theme-selector';
        selector.innerHTML = `
            <label for="theme-select">Choose a theme:</label>
            <select id="theme-select">
                ${Object.entries(this.themes).map(([key, name]) => 
                    `<option value="${key}" ${key === this.currentTheme ? 'selected' : ''}>${name}</option>`
                ).join('')}
            </select>
        `;

        // Add to game header
        const gameHeader = document.querySelector('.game-header');
        gameHeader.appendChild(selector);

        // Add event listener
        const select = document.getElementById('theme-select');
        select.addEventListener('change', (e) => {
            this.switchTheme(e.target.value);
        });

        return selector;
    }

    switchTheme(theme) {
        this.currentTheme = theme;
        const newPrompts = this.getPromptsForTheme(theme);
        
        // Update game state with new prompts
        gameState.prompts = newPrompts;
        gameState.reset();
        
        // Reset UI if game hasn't started
        if (!gameState.gameStarted) {
            newGame();
        }
    }
}

// Audio ambience (optional feature)
class AudioManager {
    constructor() {
        this.audioContext = null;
        this.currentAudio = null;
        this.enabled = false;
    }

    async initialize() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            this.enabled = true;
        } catch (error) {
            console.log('Audio not supported or blocked');
            this.enabled = false;
        }
    }

    // Placeholder for ambient audio - would need actual audio files
    playAmbientForTier(tier) {
        if (!this.enabled) return;
        
        // This would play different ambient sounds for each tier
        // surface: street chatter
        // story: subway echo  
        // soul: quiet night insects
        console.log(`Playing ambient audio for tier: ${tier}`);
    }

    stop() {
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio = null;
        }
    }
}

// Initialize enhanced features
let wordCloudGenerator;
let themeManager;
let audioManager;

// Enhanced initialization
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize enhanced features
    wordCloudGenerator = new WordCloudGenerator(elements.wordCloudCanvas);
    themeManager = new ThemeManager();
    audioManager = new AudioManager();

    // Load custom themes
    await themeManager.loadCustomPrompts();
    
    // Create theme selector
    themeManager.createThemeSelector();
    
    // Initialize audio
    await audioManager.initialize();

    // Enhanced word cloud generation
    elements.generateCloudBtn.addEventListener('click', () => {
        wordCloudGenerator.generateCloud(gameState.collectedWords);
    });

    // Enhanced PDF download
    elements.downloadPdfBtn.addEventListener('click', () => {
        PDFGenerator.generatePDF(gameState.collectedWords, gameState.prompts);
    });

    console.log('Enhanced features initialized');
});

// Update the existing generateWordCloud function
function generateWordCloud() {
    wordCloudGenerator.generateCloud(gameState.collectedWords);
}

// Update the existing downloadPDF function  
function downloadPDF() {
    PDFGenerator.generatePDF(gameState.collectedWords, gameState.prompts);
}

