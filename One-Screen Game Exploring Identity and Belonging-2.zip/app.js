// Game state management
class GameState {
    constructor() {
        this.currentTier = 'surface';
        this.currentCardIndex = 0;
        this.usedCards = { surface: [], story: [], soul: [] };
        this.gameStarted = false;
        this.gameEnded = false;
        this.reflectionActive = false;
        this.reflectionTimer = null;
        this.collectedWords = [];
        this.prompts = null;
    }

    reset() {
        this.currentTier = 'surface';
        this.currentCardIndex = 0;
        this.usedCards = { surface: [], story: [], soul: [] };
        this.gameStarted = false;
        this.gameEnded = false;
        this.reflectionActive = false;
        this.collectedWords = [];
        if (this.reflectionTimer) {
            clearInterval(this.reflectionTimer);
            this.reflectionTimer = null;
        }
    }
}

// Initialize game state
const gameState = new GameState();

// DOM elements
const elements = {
    startBtn: document.getElementById('start-btn'),
    nextBtn: document.getElementById('next-btn'),
    reflectionBtn: document.getElementById('reflection-btn'),
    currentCard: document.getElementById('current-card'),
    reflectionOverlay: document.getElementById('reflection-overlay'),
    progressRingFill: document.querySelector('.progress-ring-fill'),
    tierIndicator: document.querySelector('.tier-name'),
    tierDescription: document.querySelector('.tier-desc-text'),
    cardCount: document.getElementById('card-count'),
    gameInterface: document.querySelector('.game-interface'),
    wordCloudInterface: document.getElementById('word-cloud-interface'),
    wordInput: document.getElementById('word-input'),
    addWordBtn: document.getElementById('add-word-btn'),
    wordTags: document.getElementById('word-tags'),
    generateCloudBtn: document.getElementById('generate-cloud-btn'),
    downloadPdfBtn: document.getElementById('download-pdf-btn'),
    newGameBtn: document.getElementById('new-game-btn'),
    wordCloudCanvas: document.getElementById('word-cloud-canvas')
};

// Tier configurations
const tierConfig = {
    surface: {
        name: 'Surface',
        description: 'Surface: Ice-breakers and light reflection',
        className: 'tier-surface',
        progressOffset: 220 // Full circle
    },
    story: {
        name: 'Story',
        description: 'Story: Shared memories and personal turning points',
        className: 'tier-story',
        progressOffset: 147 // 120° filled (220 - 73)
    },
    soul: {
        name: 'Soul',
        description: 'Soul: Values, fears, and unanswered questions',
        className: 'tier-soul',
        progressOffset: 74 // 240° filled (220 - 146)
    }
};

// Load prompts from JSON
async function loadPrompts() {
    try {
        const response = await fetch('./decks/identity.json');
        gameState.prompts = await response.json();
        console.log('Prompts loaded successfully');
    } catch (error) {
        console.error('Error loading prompts:', error);
        // Fallback prompts if JSON fails to load
        gameState.prompts = {
            surface: ["Name a smell that instantly takes you back to childhood."],
            story: ["Describe a moment you realized you were both an insider and outsider at the same time."],
            soul: ["If your life were a street, what would its traffic look like today? Explain."]
        };
    }
}

// Shuffle array utility
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

// Update visual tier
function updateTierVisuals(tier) {
    const config = tierConfig[tier];
    
    // Update body class for CSS variables
    document.body.className = config.className;
    
    // Update progress ring
    elements.progressRingFill.style.strokeDashoffset = config.progressOffset;
    
    // Update tier indicator
    elements.tierIndicator.textContent = config.name;
    
    // Update tier description
    elements.tierDescription.textContent = config.description;
    
    // Add animation class
    elements.currentCard.classList.add('slide-in');
    setTimeout(() => {
        elements.currentCard.classList.remove('slide-in');
    }, 500);
}

// Get next card for current tier
function getNextCard() {
    const tierPrompts = gameState.prompts[gameState.currentTier];
    const usedCards = gameState.usedCards[gameState.currentTier];
    
    // If all cards in tier are used, move to next tier
    if (usedCards.length >= tierPrompts.length) {
        return moveToNextTier();
    }
    
    // Find unused card
    let cardIndex;
    do {
        cardIndex = Math.floor(Math.random() * tierPrompts.length);
    } while (usedCards.includes(cardIndex));
    
    // Mark card as used
    usedCards.push(cardIndex);
    
    return {
        prompt: tierPrompts[cardIndex],
        tier: gameState.currentTier,
        cardNumber: usedCards.length,
        totalCards: tierPrompts.length
    };
}

// Move to next tier
function moveToNextTier() {
    const tiers = ['surface', 'story', 'soul'];
    const currentIndex = tiers.indexOf(gameState.currentTier);
    
    if (currentIndex < tiers.length - 1) {
        gameState.currentTier = tiers[currentIndex + 1];
        updateTierVisuals(gameState.currentTier);
        return getNextCard();
    } else {
        // Game ended
        endGame();
        return null;
    }
}

// Display card
function displayCard(cardData) {
    if (!cardData) return;
    
    const cardContent = elements.currentCard.querySelector('.card-content');
    cardContent.innerHTML = `
        <div class="tier-label">${tierConfig[cardData.tier].name}</div>
        <div class="prompt-text">${cardData.prompt}</div>
        <div class="instruction-text">
            One player reads aloud, everyone answers, then tap Next.
        </div>
    `;
    
    // Update card counter
    const totalUsed = Object.values(gameState.usedCards).reduce((sum, arr) => sum + arr.length, 0);
    const totalCards = Object.values(gameState.prompts).reduce((sum, arr) => sum + arr.length, 0);
    elements.cardCount.textContent = `Card ${totalUsed} of ${totalCards}`;
}

// Start game
function startGame() {
    gameState.reset();
    gameState.gameStarted = true;
    
    // Update UI
    elements.startBtn.style.display = 'none';
    elements.nextBtn.style.display = 'inline-block';
    elements.reflectionBtn.style.display = 'inline-block';
    
    // Set initial tier
    updateTierVisuals('surface');
    
    // Display first card
    const firstCard = getNextCard();
    displayCard(firstCard);
}

// Next card
function nextCard() {
    if (gameState.reflectionActive) return;
    
    const nextCardData = getNextCard();
    if (nextCardData) {
        displayCard(nextCardData);
    }
}

// Start reflection mode
function startReflection() {
    if (gameState.reflectionActive) return;
    
    gameState.reflectionActive = true;
    elements.reflectionOverlay.classList.add('active');
    
    let timeLeft = 60;
    const countdownElement = elements.reflectionOverlay.querySelector('.timer-countdown');
    
    gameState.reflectionTimer = setInterval(() => {
        timeLeft--;
        countdownElement.textContent = timeLeft;
        
        if (timeLeft <= 0) {
            endReflection();
        }
    }, 1000);
}

// End reflection mode
function endReflection() {
    gameState.reflectionActive = false;
    elements.reflectionOverlay.classList.remove('active');
    
    if (gameState.reflectionTimer) {
        clearInterval(gameState.reflectionTimer);
        gameState.reflectionTimer = null;
    }
    
    // Reset countdown
    elements.reflectionOverlay.querySelector('.timer-countdown').textContent = '60';
}

// End game and show word cloud interface
function endGame() {
    gameState.gameEnded = true;
    elements.gameInterface.style.display = 'none';
    elements.wordCloudInterface.style.display = 'block';
    
    // Update final tier visuals
    document.body.className = 'tier-soul';
}

// Word cloud functionality
function addWord() {
    const word = elements.wordInput.value.trim();
    if (word && !gameState.collectedWords.includes(word)) {
        gameState.collectedWords.push(word);
        elements.wordInput.value = '';
        updateWordTags();
    }
}

function removeWord(word) {
    const index = gameState.collectedWords.indexOf(word);
    if (index > -1) {
        gameState.collectedWords.splice(index, 1);
        updateWordTags();
    }
}

function updateWordTags() {
    elements.wordTags.innerHTML = gameState.collectedWords.map(word => 
        `<span class="word-tag">
            ${word}
            <span class="remove" onclick="removeWord('${word}')">&times;</span>
        </span>`
    ).join('');
}

// Simple word cloud generation using canvas
function generateWordCloud() {
    const canvas = elements.wordCloudCanvas;
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (gameState.collectedWords.length === 0) {
        ctx.fillStyle = '#999';
        ctx.font = '16px Inter';
        ctx.textAlign = 'center';
        ctx.fillText('Add some words to create your cloud!', canvas.width / 2, canvas.height / 2);
        return;
    }
    
    // Simple word cloud layout
    const words = gameState.collectedWords.map((word, index) => ({
        text: word,
        size: Math.max(16, 40 - (index * 2)),
        x: Math.random() * (canvas.width - 100) + 50,
        y: Math.random() * (canvas.height - 100) + 50
    }));
    
    // Draw words
    words.forEach((word, index) => {
        ctx.fillStyle = `hsl(${(index * 137.5) % 360}, 60%, 50%)`;
        ctx.font = `${word.size}px Inter`;
        ctx.textAlign = 'center';
        ctx.fillText(word.text, word.x, word.y);
    });
}

// Download PDF functionality (simplified)
function downloadPDF() {
    // Create a simple text-based "PDF" (actually a text file)
    const content = `
Where We're From - Group Portrait

Collected Words:
${gameState.collectedWords.join(', ')}

Generated on: ${new Date().toLocaleDateString()}
    `.trim();
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'where-we-are-from-portrait.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// New game
function newGame() {
    elements.wordCloudInterface.style.display = 'none';
    elements.gameInterface.style.display = 'block';
    
    // Reset UI
    elements.startBtn.style.display = 'inline-block';
    elements.nextBtn.style.display = 'none';
    elements.reflectionBtn.style.display = 'none';
    
    // Reset game state
    gameState.reset();
    
    // Reset visuals
    document.body.className = 'tier-surface';
    elements.progressRingFill.style.strokeDashoffset = '220';
    elements.tierIndicator.textContent = 'Surface';
    elements.tierDescription.textContent = 'Surface: Ice-breakers and light reflection';
    elements.cardCount.textContent = 'Ready to begin';
    
    // Reset card content
    const cardContent = elements.currentCard.querySelector('.card-content');
    cardContent.innerHTML = `
        <div class="tier-label">Surface</div>
        <div class="prompt-text">
            Welcome to "Where We're From" — a journey through three tiers of reflection. Tap "Start Game" to begin with Surface prompts.
        </div>
        <div class="instruction-text">
            One player reads the prompt aloud, everyone answers, then tap Next for the following card.
        </div>
    `;
    
    // Clear word cloud
    gameState.collectedWords = [];
    updateWordTags();
    const canvas = elements.wordCloudCanvas;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
    await loadPrompts();
    
    // Button event listeners
    elements.startBtn.addEventListener('click', startGame);
    elements.nextBtn.addEventListener('click', nextCard);
    elements.reflectionBtn.addEventListener('click', startReflection);
    
    // Word cloud event listeners
    elements.addWordBtn.addEventListener('click', addWord);
    elements.wordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addWord();
    });
    elements.generateCloudBtn.addEventListener('click', generateWordCloud);
    elements.downloadPdfBtn.addEventListener('click', downloadPDF);
    elements.newGameBtn.addEventListener('click', newGame);
    
    // Card tap-and-hold for reflection
    let holdTimer;
    
    elements.currentCard.addEventListener('mousedown', (e) => {
        if (!gameState.gameStarted || gameState.gameEnded) return;
        
        holdTimer = setTimeout(() => {
            startReflection();
        }, 500);
    });
    
    elements.currentCard.addEventListener('mouseup', () => {
        clearTimeout(holdTimer);
    });
    
    elements.currentCard.addEventListener('mouseleave', () => {
        clearTimeout(holdTimer);
    });
    
    // Touch events for mobile
    elements.currentCard.addEventListener('touchstart', (e) => {
        if (!gameState.gameStarted || gameState.gameEnded) return;
        
        holdTimer = setTimeout(() => {
            startReflection();
        }, 500);
    });
    
    elements.currentCard.addEventListener('touchend', () => {
        clearTimeout(holdTimer);
    });
    
    // Reflection overlay click to end
    elements.reflectionOverlay.addEventListener('click', endReflection);
    
    console.log('Game initialized successfully');
});

// Make removeWord globally accessible
window.removeWord = removeWord;

